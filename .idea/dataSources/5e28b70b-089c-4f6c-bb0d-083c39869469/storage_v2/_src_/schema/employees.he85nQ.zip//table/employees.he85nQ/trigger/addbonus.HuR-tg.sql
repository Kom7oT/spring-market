create definer = root@`127.0.0.1` trigger addBonus
    after insert
    on employees
    for each row
BEGIN
	INSERT INTO salaries(emp_no, salary, from_date, to_date)
    VALUE(new.emp_no, 1000, curdate(), '9999-01-01');
END;

