create
    definer = root@`127.0.0.1` procedure fire_out(IN empl_id int, OUT result char(40))
begin
declare work_in int default 0;
declare exit handler for sqlexception
	begin
		rollback;
        set result = 'что то пошло не так';
	end;
     start transaction;
		select count(*) into work_in from titles where emp_no = empl_id and to_date = '9999-01-01';
        if work_in = 1  then 
        begin 			
			UPDATE salaries SET to_date = curdate() WHERE (emp_no = empl_id) AND (to_date = '9999-01-01');
			UPDATE dept_emp SET to_date = curdate() WHERE (emp_no = empl_id) AND (to_date = '9999-01-01');
			UPDATE titles SET to_date = curdate() WHERE (emp_no = empl_id) AND (to_date = '9999-01-01');
			commit;
            set result = 'Успех!';
		end;
     else set result = 'человек уже уволен';
     end if;
end;

