create
    definer = root@`127.0.0.1` function findmanager(dept_id char(4)) returns varchar(6)
begin
declare asd varchar(6);
return ( SELECT 
    emp_no 
FROM
    employees.dept_manager 
    inner join departments dp using (dept_no)
    inner join employees ep using (emp_no)
WHERE
    to_date = '9999-01-01'
    AND dept_id = dept_no
    );

end;

